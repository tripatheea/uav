import glob
images = glob.glob('*.png')

for img in images:
    
