function convert_coordinates(x, y, zoom, tileSize) {
  var numTiles = 1 << zoom;

  pixelX = x * tileSize;
  pixelY = y * tileSize;

  convertedX = pixelX / Math.pow(2, zoom);
  convertedY = pixelY / Math.pow(2, zoom);

  return [convertedX, convertedY];
}
