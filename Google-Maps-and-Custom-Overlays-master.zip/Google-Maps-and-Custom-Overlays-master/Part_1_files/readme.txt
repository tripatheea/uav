I'me included this folder is just a 'place holder' or reminder of where the image for the "Downloading a template" section should be.

However, I've not included the image file itself to ensure we not break Google's copyright rules.

