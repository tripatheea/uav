Google-Maps-and-Custom-Overlays
===============================

In our previous tutorial we looked at how you can add markers and customize the colors and menus of a Google map using the service’s API. This tutorial takes things a step further, explaining how you can create your own custom map and overlay it onto a Google map.
http://enva.to/12TzxCj
