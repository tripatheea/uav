The files in this folder were used in the "Creating your own map" section.

(The actual photoshop file in which this map was created was far far too big to include here! 
This photoshop file had the map generated in the previous section one one layer, and the weather map was drawn on top on another layer. 
Then the 'template map' layer was hidden, and this map saved as a png.)