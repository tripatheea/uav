The files in this folder were used in the "Slicing up your map" section.

Note: These files were outputted from the older version of the MapTiler software and so the files are in the incorrect TMS format. (If you are using the new version of MapTiler yours will be in the correct Google format.

The next 'Part_4_files' folder contains the version of these tiles that have been renamed into the Google format.